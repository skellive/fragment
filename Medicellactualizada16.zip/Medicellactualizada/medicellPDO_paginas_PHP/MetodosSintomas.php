<?php 

    require_once 'conexionPDO.php';
    switch($_GET['funcion']){
        case 'obtenerSintomas':
            $metodos = new Metodos();
            $objDatos = $metodos->obtenerSintomas();
        break;
    }
    class Metodos{

        public function obtenerSintomas(){
            $database = new conexionPDO();
            $objConexion = $database->conexion();
            $sql = "SELECT * FROM sintomas";
            $sentencia = $objConexion->prepare($sql);
            $sentencia->execute();
            $array_datos = array();
            while($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
                $array_datos[] = $row;
            }
            echo json_encode($array_datos);
        }
    }
?>