<?php 

 class conexionPDO{
        private $servername = "localhost";
        private $username = "root";
        private $password = "root";
        private $db_name = "medicell";
        private $con;

        public function conexion(){
            $this->con=null;
            try{
                $this->con = new PDO("mysql:host=".$this->servername.";dbname=".$this->db_name,$this->username,$this->password);
                $this->con->exec("set names utf8");
            }catch(PDOException $ex){
                echo "error al conectar: ".$ex->getMessage();

            }
            return $this->con;
        }
 }
 //$database = new Database();
 //$objConexion = $database->conexion();
?>