<?php 

$usuario = $_REQUEST['usuario'];
$contrasenia = $_REQUEST['contrasenia'];

$cnx = new PDO("mysql:host=localhost; dbname=medicell","root","root");
$res=$cnx->query("select * from user where usuario='$usuario' and contrasenia = '$contrasenia'");

$datos = array();
foreach ($res as $row){
    $datos[]=$row;
}

echo json_encode($datos, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION | JSON_PRETTY_PRINT);



  ?>