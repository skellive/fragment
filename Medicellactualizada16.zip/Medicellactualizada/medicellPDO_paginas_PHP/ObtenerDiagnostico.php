<?php

    require "conexionMetDiagnostico.php";
    
    $sql = "SELECT * FROM diagnostico_user";
    $query = $mysqli->query($sql);
    
    $datos = array();
    
    while($resultado = $query->fetch_assoc()) {
        $datos[] = $resultado;
    }
    
    echo json_encode(array("Diagnostico" => $datos));
    
?>