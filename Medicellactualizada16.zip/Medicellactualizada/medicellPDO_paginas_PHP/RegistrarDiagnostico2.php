<?php
    
    $server = "localhost";
    $user = "root";
    $pass = "root";
    $bd = "medicell";
    
    $json = $_POST['json'];
    
    $jsonDecode = json_decode($json, true);
    
    $conexion = mysqli_connect($server, $user, $pass,$bd)
    or die("Ha sucedido un error inexperado en la conexion de la base de datos");
    
    foreach($jsonDecode['Diagnostico'] as $fila) {
        $nombre_apellido = mysqli_real_escape_string($conexion, $fila['nombre_apellido']);
        $sintomas_presentados = mysqli_real_escape_string($conexion, $fila['sintomas_presentados']);
        $Diagnostico = mysqli_real_escape_string($conexion, $fila['Diagnostico']);
        $enfermedad_presentada = mysqli_real_escape_string($conexion, $fila['enfermedad_presentada']);
        
        
        $sql = "INSERT INTO diagnostico_user (nombre_apellido, sintomas_presentados, Diagnostico, enfermedad_presentada) VALUES ('$nombre_apellido', '$sintomas_presentados', 'Presenta un cuadro de enfermedad cardiaca, se recomienda seguir una dieta con bajo contenido de grasa y bajo contenido de sodio, realizar por lo menos 30 minutos de ejercicio moderado la mayoria de dias de la semana', 'Enfermedades cardiovasculares')";
        
        mysqli_query($conexion, $sql);
    }
    
    echo "OK";
    
    mysqli_close($conexion);

    
?>

