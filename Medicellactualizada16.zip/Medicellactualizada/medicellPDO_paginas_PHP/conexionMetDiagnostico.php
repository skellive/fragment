
    <?php
	
	$mysqli = new mysqli('localhost', 'root', 'root', 'medicell');
	
	if($mysqli->connect_error){
		
		die('Error en la conexion' . $mysqli->connect_error);
		
	}else {
       
        //echo 'Conexion exitosa';
    }
		

	
?>