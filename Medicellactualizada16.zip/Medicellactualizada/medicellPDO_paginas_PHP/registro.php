<?php 
//error_reporting(0);

$conexion = mysqli_connect("localhost", "root", "root", "medicell");

if(!$conexion){
    exit("Error al intentar conectarse al servidor");
}

$nombre = $_REQUEST['nombre'];
$apellido = $_REQUEST['apellido'];
$usuario = $_REQUEST['usuario'];
$contrasenia = $_REQUEST['contrasenia'];

$statement = mysqli_prepare($conexion,"insert into user(nombre, apellido, usuario, contrasenia) values(?, ?, ?, ?)");
mysqli_stmt_bind_param($statement, "ssss", $nombre, $apellido, $usuario, $contrasenia);
 
$response = array();
$response["success"] = true;
echo json_encode($response);
/*
if($response>0){
    
    echo "Registrado con exito.";
}else{
    echo "Error al registrar, intente nuevamente";
}

mysql_close($conexion);*/



?>