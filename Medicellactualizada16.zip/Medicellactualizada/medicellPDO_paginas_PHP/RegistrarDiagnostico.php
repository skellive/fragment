<?php
    
    $server = "localhost";
    $user = "root";
    $pass = "root";
    $bd = "medicell";
    
    $json = $_POST['json'];
    
    $jsonDecode = json_decode($json, true);
    
    $conexion = mysqli_connect($server, $user, $pass,$bd)
    or die("Ha sucedido un error inexperado en la conexion de la base de datos");
    
    foreach($jsonDecode['Diagnostico'] as $fila) {
        $nombre_apellido = mysqli_real_escape_string($conexion, $fila['nombre_apellido']);
        $sintomas_presentados = mysqli_real_escape_string($conexion, $fila['sintomas_presentados']);
        $Diagnostico = mysqli_real_escape_string($conexion, $fila['Diagnostico']);
        $enfermedad_presentada = mysqli_real_escape_string($conexion, $fila['enfermedad_presentada']);
        
        
        $sql = "INSERT INTO diagnostico_user (nombre_apellido, sintomas_presentados, Diagnostico, enfermedad_presentada) VALUES ('$nombre_apellido', '$sintomas_presentados', 'Presenta una enfermedad leve, lo que se podria deducir que es una gripe comun', 'Gripe comun')";
        
        mysqli_query($conexion, $sql);
    }
    
    echo "OK";
    
    mysqli_close($conexion);
    
?>
