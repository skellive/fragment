/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 5.7.26-log : Database - medicell
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`medicell` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `medicell`;

/*Table structure for table `diagnostico` */

DROP TABLE IF EXISTS `diagnostico`;

CREATE TABLE `diagnostico` (
  `id_diagnostico` int(11) NOT NULL,
  `Diagnostico` varchar(255) NOT NULL,
  `enfermedades_has_diagnostico_diagnostico_id_diagnostico` int(11) NOT NULL,
  PRIMARY KEY (`id_diagnostico`,`enfermedades_has_diagnostico_diagnostico_id_diagnostico`),
  KEY `fk_diagnostico_enfermedades_has_diagnostico1_idx` (`enfermedades_has_diagnostico_diagnostico_id_diagnostico`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `diagnostico` */

LOCK TABLES `diagnostico` WRITE;

insert  into `diagnostico`(`id_diagnostico`,`Diagnostico`,`enfermedades_has_diagnostico_diagnostico_id_diagnostico`) values 
(1,'Presenta una enfermedad leve, lo que se podria deducir que es una gripe comun',1),
(2,'Presenta un cuadro de enfermedad cardiaca, se recomienda seguir una dieta con bajo contenido de grasa y bajo contenido de sodio, realizar por lo menos 30 minutos de ejercicio moderado la mayoria de dias de la semana',2);

UNLOCK TABLES;

/*Table structure for table `diagnostico_user` */

DROP TABLE IF EXISTS `diagnostico_user`;

CREATE TABLE `diagnostico_user` (
  `nombre_apellido` varchar(255) DEFAULT NULL,
  `sintomas_presentados` varchar(255) DEFAULT NULL,
  `Diagnostico` varchar(400) DEFAULT NULL,
  `Enfermedad_presentados` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `diagnostico_user` */

LOCK TABLES `diagnostico_user` WRITE;

UNLOCK TABLES;

/*Table structure for table `enfermedades` */

DROP TABLE IF EXISTS `enfermedades`;

CREATE TABLE `enfermedades` (
  `id_enfermedades` int(11) NOT NULL,
  `nombre_enfermedades` varchar(45) NOT NULL,
  `enfermedades_has_diagnostico_diagnostico_id_diagnostico` int(11) NOT NULL,
  PRIMARY KEY (`id_enfermedades`,`enfermedades_has_diagnostico_diagnostico_id_diagnostico`),
  KEY `fk_enfermedades_enfermedades_has_diagnostico1_idx` (`enfermedades_has_diagnostico_diagnostico_id_diagnostico`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `enfermedades` */

LOCK TABLES `enfermedades` WRITE;

insert  into `enfermedades`(`id_enfermedades`,`nombre_enfermedades`,`enfermedades_has_diagnostico_diagnostico_id_diagnostico`) values 
(1,'Gripe comun',1),
(2,'Enfermedades cardiovasculares',2),
(3,'Obesidad',3),
(4,'Diabetes',4),
(5,'Asma',5),
(6,'Caries',6),
(7,'Estres',7);

UNLOCK TABLES;

/*Table structure for table `enfermedades_has_diagnostico` */

DROP TABLE IF EXISTS `enfermedades_has_diagnostico`;

CREATE TABLE `enfermedades_has_diagnostico` (
  `diagnostico_id_diagnostico` int(11) NOT NULL,
  `enfermedades_id_enfermedades` int(11) NOT NULL,
  PRIMARY KEY (`diagnostico_id_diagnostico`,`enfermedades_id_enfermedades`),
  KEY `enfermedades_id_enfermedades` (`enfermedades_id_enfermedades`),
  CONSTRAINT `enfermedades_has_diagnostico_ibfk_1` FOREIGN KEY (`diagnostico_id_diagnostico`) REFERENCES `diagnostico` (`id_diagnostico`),
  CONSTRAINT `enfermedades_has_diagnostico_ibfk_2` FOREIGN KEY (`enfermedades_id_enfermedades`) REFERENCES `enfermedades` (`id_enfermedades`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `enfermedades_has_diagnostico` */

LOCK TABLES `enfermedades_has_diagnostico` WRITE;

insert  into `enfermedades_has_diagnostico`(`diagnostico_id_diagnostico`,`enfermedades_id_enfermedades`) values 
(1,1),
(2,2);

UNLOCK TABLES;

/*Table structure for table `enfermedades_sintomas` */

DROP TABLE IF EXISTS `enfermedades_sintomas`;

CREATE TABLE `enfermedades_sintomas` (
  `id_sintomas` int(11) NOT NULL,
  `id_enfermedades` int(11) NOT NULL,
  PRIMARY KEY (`id_sintomas`,`id_enfermedades`),
  KEY `id_enfermedades` (`id_enfermedades`),
  CONSTRAINT `enfermedades_sintomas_ibfk_1` FOREIGN KEY (`id_sintomas`) REFERENCES `sintomas` (`id_sintomas`),
  CONSTRAINT `enfermedades_sintomas_ibfk_2` FOREIGN KEY (`id_enfermedades`) REFERENCES `enfermedades` (`id_enfermedades`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `enfermedades_sintomas` */

LOCK TABLES `enfermedades_sintomas` WRITE;

insert  into `enfermedades_sintomas`(`id_sintomas`,`id_enfermedades`) values 
(1,1),
(2,1),
(3,1),
(4,1),
(5,1),
(6,1),
(7,1),
(8,1),
(9,2),
(10,2),
(11,2),
(12,2),
(13,2),
(14,2),
(15,2),
(16,2),
(17,2),
(18,2),
(19,2),
(20,2),
(21,2),
(22,2);

UNLOCK TABLES;

/*Table structure for table `sintomas` */

DROP TABLE IF EXISTS `sintomas`;

CREATE TABLE `sintomas` (
  `id_sintomas` int(11) NOT NULL AUTO_INCREMENT,
  `sintomas` varchar(400) NOT NULL,
  `enfermedades_id_enfermedades` int(11) NOT NULL,
  PRIMARY KEY (`id_sintomas`,`enfermedades_id_enfermedades`),
  KEY `fk_sintomas_enfermedades1_idx` (`enfermedades_id_enfermedades`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Data for the table `sintomas` */

LOCK TABLES `sintomas` WRITE;

insert  into `sintomas`(`id_sintomas`,`sintomas`,`enfermedades_id_enfermedades`) values 
(0,'Seleccionar opcion',0),
(1,'Fiebre',1),
(2,'Escalofrios',1),
(3,'Dolor de cabeza',1),
(4,'Molestias de garganta',1),
(5,'Malestar general',1),
(6,'Dolores musculares',1),
(7,'Congestion nasal',1),
(8,'Inflamacion de la garganta',1),
(9,'Aleteo en el pecho',2),
(10,'Latidos cardiacos acelerados(taquicardia)',2),
(11,'Latidos cardiacos lentos(bradicardia)',2),
(12,'Dolor en el pecho o malestar',2),
(13,'Dificultad para respirar',2),
(14,'Aturdimiento',2),
(15,'Desmayos (sincope) o sensacion de desmayo',2),
(16,'Color de piel palido o azul',2),
(17,'Hinchazon en las piernas',2),
(18,'Cansarse facilmente durante el ejercicio',2),
(19,'Hinchazon de las manos, los tobillos o los pies',2),
(20,'Cansancio',2),
(21,'Latidos irregulares(se sienten rapidos, fuertes o como aleteos)',2),
(22,'Erupciones cutaneas o manchas inusuales',2);

UNLOCK TABLES;

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  `correo` varchar(45) DEFAULT NULL,
  `contrasenia` varchar(45) NOT NULL,
  `sexo` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user` */

LOCK TABLES `user` WRITE;

insert  into `user`(`nombre`,`apellido`,`usuario`,`correo`,`contrasenia`,`sexo`) values 
('Drubber','Sanchez','desanchez','drubber2000@hotmail.com','hola','Masculino'),
('Damaris','Perez','dperez',NULL,'123456',NULL),
('Luis','Constante','lconstante',NULL,'123456',NULL);

UNLOCK TABLES;

/* Trigger structure for table `diagnostico_user` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `diagnostico` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `diagnostico` BEFORE INSERT ON `diagnostico_user` FOR EACH ROW BEGIN    
		
	UPDATE diagnostico_user set Diagnostico = 'Presenta una enfermedad leve, lo que se podria deducir que es una gripe comun' where id_diagnostico = 1;	
	
		
		
    END */$$


DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
