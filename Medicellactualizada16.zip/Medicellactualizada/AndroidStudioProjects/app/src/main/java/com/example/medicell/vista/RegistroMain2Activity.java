package com.example.medicell.vista;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.example.medicell.R;
import com.example.medicell.controlador.RegisterRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class RegistroMain2Activity extends AppCompatActivity implements View.OnClickListener {
    private EditText mTextNombre, mTextApellido, mTextUsuario, mTextPassword, mTextConfPassword;
    private Button mButtonRegistrar, mButtonIniciar;
    private CheckBox mRecord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_registro_main2);

        mTextNombre = (EditText) findViewById(R.id.edittext_nombre);
        mTextApellido =(EditText) findViewById(R.id.edittext_apellido);
        mTextUsuario = (EditText) findViewById(R.id.edittext_usuario);
        mTextPassword = (EditText) findViewById(R.id.edittext_password);
        mTextConfPassword = (EditText) findViewById(R.id.edittext_conf_password);
        mButtonRegistrar = (Button) findViewById(R.id.button_registrar);
        mButtonIniciar = (Button) findViewById(R.id.button_Iniciar);


        mButtonRegistrar.setOnClickListener(this);

        mRecord= (CheckBox) findViewById(R.id.record);
    }

    @Override
    public void onClick(View v) {
       /* if(!mTextNombre.getText().toString().isEmpty() || !mTextApellido.getText().toString().isEmpty() || !mTextUsuario.getText().toString().isEmpty() || !mTextPassword.getText().toString().isEmpty() || !mTextConfPassword.getText().toString().isEmpty()){
            if(mTextPassword.getText().toString().equals(mTextConfPassword.getText().toString())) {

                new DesImagen(RegistroMain2Activity.this).execute(mTextNombre.getText().toString(), mTextApellido.getText().toString(), mTextUsuario.getText().toString(), mTextPassword.getText().toString());

            }else{
                Toast.makeText(getApplicationContext(), "Contraseñas no coinciden", Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(getApplicationContext(), "Debe de llenar todos los campos", Toast.LENGTH_LONG).show();

        }*/
       /* final String nombre = mTextUsuario.getText().toString();
        final String apellido = mTextApellido.getText().toString();
        final String usuario = mTextUsuario.getText().toString();
        final String contrasenia = mTextPassword.getText().toString();*/

        Response.Listener<String>respListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");

                    if(success){
                        Toast.makeText(getApplicationContext(), "Se ha registrado con exito.", Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(getApplicationContext(), "Error al registrar", Toast.LENGTH_LONG).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        RegisterRequest registerRequest = new RegisterRequest(mTextNombre.getText().toString(), mTextApellido.getText().toString(), mTextUsuario.getText().toString(), mTextPassword.getText().toString(), respListener);
        RequestQueue queue = Volley.newRequestQueue(RegistroMain2Activity.this);
        queue.add(registerRequest);
    }

   /* public class DesImagen extends AsyncTask<String, Void, String> {
        private WeakReference<Context> context;
        public DesImagen(Context context){
            this.context = new WeakReference<>(context);
        }
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        protected String  doInBackground(String... params){
            String registrar_url = "http://192.168.1.2:8080/medicellPDO/registrar.php";
            String resultado = null;

            try {
                URL url = new URL(registrar_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8));

                String nombre = params[0];
                String apellido = params[1];
                String usuario= params[2];
                String contrasenia = params[3];

                String data = URLEncoder.encode("nombre", "UTF-8")+ "=" + URLEncoder.encode(nombre, "UTF-8") +
                        "&"+ URLEncoder.encode("apellido", "UTF-8")+ "=" + URLEncoder.encode(apellido, "UTF-8") +
                        "&"+ URLEncoder.encode("usuario", "UTF-8")+ "=" + URLEncoder.encode(usuario, "UTF-8") +
                        "&"+URLEncoder.encode("contrasenia", "UTF-8")+ "=" + URLEncoder.encode(contrasenia, "UTF-8");

                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
                StringBuilder stringBuilder = new StringBuilder();

                String line;
                while((line = bufferedReader.readLine()) != null){
                    stringBuilder.append(line);
                }
                resultado = stringBuilder.toString();
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();



            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return resultado;
        }

        protected  void onPostExecute(String resultado){
            Toast.makeText(RegistroMain2Activity.this, resultado, Toast.LENGTH_LONG).show();
        }



    }*/



    public void loguearCheckbox(View v) {
        String s = "Estado: " + (mRecord.isChecked() ? "Marcado" : "No Marcado");
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
